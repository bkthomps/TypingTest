Bailey Thompson
Typing Test (1.1.0)
1 February 2016

To start the typing test start typing the second line of words. They will then disappear until no words are 
left, and at that point, the second line of words will be the first line of words. The words are generated from 
a list of the approximately nine thousand most common words. Once done the test, your words per minute (WPM) and 
characters per minute (CPM) will be displayed. The high score is also kept even through different instances of 
play.


If you do not have the Java 8 JRE, please follow these steps.
1. Go to this website: http://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html
2. Accept the license agreement
3. Download the version that best suits your operating system
4. Wait for the download to be completed
5. Start the .jar file in the folder in which you found these instructions